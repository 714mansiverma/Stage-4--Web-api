﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HandsOn3
{
    public class Department
    {
        public int deptId { get; set; }
        public string deptName { get; set; }
    }
}
