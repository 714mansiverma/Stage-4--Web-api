﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HandsOn3
{
    public class Skill
    {
        public List<string> vs { get; set; }
    }
}
